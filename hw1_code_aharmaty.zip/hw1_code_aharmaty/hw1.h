#ifndef HW1_H
#define HW1_H

#include <stdio.h>
#include <stdarg.h>

#define printf myprintf

void myprintf(const char *format, ...);

#define MYMSG(msg, ...) do { \
    printf("Original message --> %s:%d: " msg, __FILE__, __LINE__, ##__VA_ARGS__); \
} while(0)

#endif