#include <stdio.h>
#include <stdarg.h>

void myprintf(const char *format, ...) {
    va_list args;
    
    // Print formatted string
    va_start(args, format);
    vprintf(format, args); 
    va_end(args);

    printf("\nArgument list:\n");

    // Iterate through each argument
    va_start(args, format); 
    const char *p = format;
    while (*p) {
        if (*p == '%') {
            ++p; 
            switch (*p) {
                case 'c': { // Character
                    char character = (char)va_arg(args, int);
                    printf("Char --> %c\n", character);
                    break;
                }
                case 'd': { // Integer
                    int integer = va_arg(args, int);
                    printf("Integer --> %d\n", integer);
                    break;
                }
                case 's': { // String
                    char *string = va_arg(args, char*);
                    printf("String --> %s\n", string);
                    break;
                }
            }
        }
        p++; 
    }
    va_end(args);
}