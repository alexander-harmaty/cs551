#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int occurrences(const char *string, const char *substring);
char* reverse(const char *original);

// Main function
int str_manip(const char *str, const char *substr) {
    // Validate & print input
    if (!str || !substr) {
        fprintf(stderr, "Error: Cannot be null.\n");
        return -1;
    }
    printf("Input: %s\n", str);

    // Revserse & print string
    char *newStr = reverse(str);
    if (!newStr) {
        fprintf(stderr, "Error: Failed to allocate memory for transformed string.\n");
        return -1;
    }
    printf("Transformed: %s\n", newStr);

    // Search, count, & print occurrences
    printf("Search for: %s\n", substr);
    int count = occurrences(newStr, substr);
    printf("Found %d occurrences\n", count);

    free(newStr);
    return 0;
}

// Reverse & duplicate a string, conversion to lowercase
char* reverse(const char *original) {
    size_t len = strlen(original);
    char *result = malloc(2 * len + 1); // allocate memory for reversed string
    if (!result) return NULL;

    // Copy & convert to lowercase
    for (size_t i = 0; i < len; ++i) {
        result[i] = tolower(original[i]);
    }   
    // Append reversed string in lowercase 
    for (size_t i = 0; i < len; ++i) {
        result[len + i] = tolower(original[len - 1 - i]);
    }
    result[2 * len] = '\0';
    return result;
}

// Count occurrences of substring in string
int occurrences(const char *string, const char *substring) {
    int count = 0;
    size_t subLength = strlen(substring);
    size_t stringLength = strlen(string);

    // Search
    for (size_t i = 0; i <= stringLength - subLength; i++) {
        size_t j;
        for (j = 0; j < subLength; j++) {
            if (tolower(string[i + j]) != tolower(substring[j])) break;
        }
        if (j == subLength) count++; // Found
    }
    return count;
}